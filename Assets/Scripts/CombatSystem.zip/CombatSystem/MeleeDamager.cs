using UnityEngine;

public abstract class MeleeDamager : MonoBehaviour
{
    public abstract float GetMeleeDamage();
}