public enum WorkTypes
{
    Chopping, 
    Minining, 
    Building
}