public enum InventoryEvent
{
    RemoveItem,
    AddItem
}
